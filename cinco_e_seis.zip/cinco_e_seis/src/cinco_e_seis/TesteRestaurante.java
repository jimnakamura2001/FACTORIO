package cinco_e_seis;

import cinco_e_seis.Pedido;

public class TesteRestaurante extends Pedido{


    public TesteRestaurante(String cliente, String ultimoPedido, double valorTotal){
        super(cliente, ultimoPedido, valorTotal);
    }

    public TesteRestaurante(String cliente, String ultimoPedido){
        super(cliente, ultimoPedido);
    }

    public String statusUltimoPedido(){

        StringBuilder statusPedido = new StringBuilder();

        statusPedido.append(super.getCliente()).append(" pediu ").append(super.getUltimoPedido()).append(" no valor de ").append(" R$").append(super.getValorTotal());

        if(super.isPedidoPendente()){
            
            statusPedido.append(" \n O pedido esta pendente!\n" );
        }
        else{
            statusPedido.append(" \n O pedido ja foi entregue! :D \n");
        }
        
		return statusPedido.toString();

      
    }


}
