package cinco_e_seis;

import java.util.Scanner;

import cinco_e_seis.TesteRestaurante;

public class AppRestauras {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Scanner banana = new Scanner(System.in);
		boolean continuar = true;
		
		System.out.println("Insira o nome do cliente: ");
		String cliente = input.nextLine();

		System.out.println("Insira o nome do prato pedido: ");
		String pedido = input.nextLine();

		TesteRestaurante restaurasdaora = new TesteRestaurante(cliente, pedido);

		restaurasdaora.fazPedido();
		System.out.println(" Pedido regsitrado! \n" );
		
		while(continuar){

			System.out.println("Selecione o que quer fazer: \n"
			+ "\n"
			+ "1. Para mostrar o status do seu pedido \n"
			+ "2. Para Concluir o pedido \n"
			+ "3. Para sair e encerrar \n");

			int escolha = banana.nextInt();

			switch(escolha){

				case 1:
					System.out.println(restaurasdaora.statusUltimoPedido());
					break;

				case 2:
					System.out.println("Pedido Concluido!");
					restaurasdaora.entregaPedido();

					System.out.println("Deseja fazer um novo pedido?\n"
					+ "Digite (sim/nao)\n");

					boolean novoPedido = input.nextLine().equals("sim");

					if(novoPedido){

						System.out.println("Insira o nome do cliente: ");
						cliente = input.nextLine();

						System.out.println("Insira o nome do prato pedido: ");
						pedido = input.nextLine();

						restaurasdaora.setCliente(cliente);
						restaurasdaora.setUltimoPedido(pedido);
						restaurasdaora.setPedidoPendente(true);
						restaurasdaora.fazPedido();
						
						System.out.println("Pedido registrado! XD ");
						}
					else{
						break;
					}
					break;
				case 3:
					System.out.println("Deseja mesmo fechar sua aplicacao?");

					continuar = false;
					break;
				}

			}
		}
	}


